


COUPONS = {
    "expired":[
        {"code": "superbowl50", "discount": 50},
    ],
    "valid": [
        {"code": "90off", "discount": 90},
        {"code": "50off", "discount": 50},
        {"code": "10off", "discount": 10}
    ]
}