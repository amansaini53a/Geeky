from setuptools import setup, find_packages

setup(name='DemoLibraries',
      version='0.1',
      description='Demo package for the course',
      url='http://supersqa.com',
      author='Admas Kinfu',
      author_email='admas@example.com',
      license='SSQA',
      packages=find_packages(),
      zip_safe=False)
